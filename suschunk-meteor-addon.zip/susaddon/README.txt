Clone https://github.com/MeteorDevelopment/meteor-addon-template (the branch for 1.21.11),
then copy the two .java files from src/main/java/com/example/addon/ into the template's
matching folders (replace the template's main addon class; make sure fabric.mod.json
points its "meteor" entrypoint at com.example.addon.SusChunkAddon and keep the template's
build files / versions as they are).
Build: ./gradlew build  ->  build/libs/*.jar
